// Lista de alunos cadastrados
// array
const alunos = []

// função para cadastro de alunos
const btn = document.getElementById("btn1")

btn.addEventListener("click", function cadastroAluno() {

  const nome = document.getElementById("nome").value;
  const email = document.getElementById("e-mail").value;
  const telefone = document.getElementById("telefone").value;
  const CEP = document.getElementById("CEP").value;
  const endereço = document.getElementById("endereço").value;
  const número = document.getElementById("número").value
  const complemento = document.getElementById("complemento").value
  const bairro = document.getElementById("bairro").value
  const cidade = document.getElementById("cidade").value
  const estado = document.getElementById("estado").value

  // contador
  const caption = document.getElementById("title1");

  const number = caption.innerText = alunos.length + 1
  const string = "Usuários Cadastrados"

  const Fusion = `${number} ${string}`
  // console.log(Fusion)

  title1.innerText = Fusion

  // validação
  let alertaCampo = "";
  if (nome === "") {
    alertaCampo += "Preencha o campo nome. \r\n";
  }

  if (email === "") {
    alertaCampo += "Preencha o campo e-mail. \r\n";
  }

  if (telefone === "") {
    alertaCampo += "Preencha o campo telefone. \r\n";
  }

  if (CEP === "") {
    alertaCampo += "Preencha o campo CEP. \r\n";
  }

  if (endereço === "") {
    alertaCampo += "Preencha o campo endereço. \r\n";
  }

  if (número === "") {
    alertaCampo += "Preencha o campo número. \r\n";
  }

  if (bairro === "") {
    alertaCampo += "Preencha o campo bairro. \r\n";
  }

  if (cidade === "") {
    alertaCampo += "Preencha o campo cidade. \r\n";
  }

  if (estado === "") {
    alertaCampo += "Preencha o campo estado. \r\n";
  }

  if (alertaCampo !== "") {
    alert(alertaCampo);
  }

  // objeto 
  const aluno = {
    nome,
    email,
    telefone,
    CEP,
    endereço,
    número,
    complemento,
    bairro,
    cidade,
    estado,
    data: new Date().toLocaleDateString(),
  }

  alunos.push(aluno)
  renderTable();
  // console.log(alunos.length)
  // console.log(alunos)
})

// função para mostrar os alunos na tabela
function renderTable() {
  const tbody = document.getElementById("tbody");
  tbody.innerHTML = "";
  for (let aluno of alunos) {

    // Nessa linha estamos pegando a posição do usuário em questão
    const pos = alunos.indexOf(aluno)

    const user = `
     <tr>
      <td>${aluno.nome}</td>
      <td>${aluno.email}</td>
      <td>${aluno.telefone}</td>
      <td>${aluno.CEP}</td>
      <td>${aluno.endereço}</td>
      <td>${aluno.número}</td>
      <td>${aluno.complemento}</td>
      <td>${aluno.bairro}</td>
      <td>${aluno.cidade}</td>
      <td>${aluno.estado}</td>
      <td>${aluno.data}</td>
      <td>
        <a onclick="removeLinha(${pos})">
          <img src="delete.png">
        </a>
      </td>
     </tr>
    `;
    tbody.innerHTML += user;
  }
}

// função para remover linha selecionada da tabela
function removeLinha(pos) {
  alunos.splice(pos, 1)
  renderTable()
}


