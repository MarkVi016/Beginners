const btn = document.querySelector("#button");

btn.addEventListener("click", function Potentiation() {
  var isOk = true;
  var valor1 = document.getElementById("valor1").value;
  var valor2 = document.getElementById("valor2").value;
  var resultado = (Math.pow(parseInt(valor1), parseInt(valor2)));

  if (valor1 == '' || valor1 == null) {
    alert("Preencha o primeiro valor");
    isOk = false;
  }

  if (valor2 == '' || valor2 == null) {
    alert("Preencha o segundo valor");
    isOk = false;
  }

  if (isOk) {
    document.querySelector("#resultado").innerText = resultado;
  }
}
)