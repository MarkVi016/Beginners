const btn = document.querySelector("#button");

btn.addEventListener("click", function ReturnInt() {
  var isOk = true;
  var valor1 = document.getElementById("valor1").value;
  var resultado = (Math.round(parseFloat(valor1)));

  if (valor1 == '' || valor1 == null) {
    alert("Preencha o primeiro valor");
    isOk = false;
  }

  if (isOk) {
    document.querySelector("#resultado").innerText = resultado;
  }
}
)