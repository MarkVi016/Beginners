const btn1 = document.querySelector("#button1");

btn1.addEventListener("click", function Circumference() {
  var isOk = true;
  var valor1 = document.getElementById("valor1").value;
  var resultado1 = (2 * Math.PI * valor1).toFixed(2);

  if (valor1 == '' || valor1 == null) {
    alert("Preencha o primeiro valor");
    isOk = false;
  }

  if (isOk) {
    document.querySelector("#resultado1").innerText = resultado1;
  }
}
)

const btn2 = document.querySelector("#button2");

btn2.addEventListener("click", function Area() {
  var isOk = true;
  var value1 = document.getElementById("value1").value;
  var resultado2 = (Math.pow(value1, 2) * Math.PI).toFixed(1);

  if (value1 == '' || value1 == null) {
    alert("Preencha o primeiro valor");
    isOk = false;
  }

  if (isOk) {
    document.querySelector("#resultado2").innerText = resultado2;
  }
}
)